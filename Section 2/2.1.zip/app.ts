let userName: string;
userName = 'Jennifer';
console.log(userName);

console.log('Hello ' + userName);

//userName = '1';

let numberOne = 10;
let numberTwo: number = 5;

console.log(numberTwo * 2 + numberOne);

let isActive: boolean = true;
let isFree: boolean;

console.log(isActive);

const employeeName = 'John';
//employeeName = 'Ahmad';

console.log(employeeName);
