console.log('Arithmetic Operators');

let numberOne = 10;
let numberTwo = 3;

console.log(numberOne + numberTwo);
console.log(numberOne - numberTwo);
console.log(numberOne * numberTwo);
console.log(numberOne / numberTwo);

console.log('Increment and Decrement');
console.log(numberOne--);
console.log(numberOne);

console.log('Logical Operators');
let firstCondition = false;
let secondCondition = false;

console.log(true && secondCondition);
console.log(firstCondition || secondCondition);
console.log(!secondCondition);

console.log('Comparision Operators');
let marchIncome = 3000;
let aprilIncome = 4000;

console.log(marchIncome == '3000');
console.log(marchIncome === '3000');

console.log(marchIncome != 3000);
console.log(marchIncome !== '3000');

let mayIncome = 4000;
console.log(mayIncome >= aprilIncome);


