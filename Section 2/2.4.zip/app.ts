let employeeAdam: [number, string, string, boolean];
let employeeEmma: [number, string, string, boolean];

employeeAdam = [100, 'Adam', 'Software Developer', true];
employeeEmma = [103, 'Emma', 'Designer', true];

console.log(employeeAdam);
console.log(employeeEmma);
