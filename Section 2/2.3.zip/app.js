var arrayOne;
var arrayTwo = [];
var arrayThree = new Array();
var arrayFour = Array();
var salaries = [2000, 3000, 9000, 1000];
console.log(salaries[3]);
var arrayNo = [];
console.log('Before Filling Array');
console.log(arrayNo);
arrayNo.push(1);
arrayNo.push(2);
arrayNo.push(3);
console.log(arrayNo);
console.log('After Filling Array');
console.log(arrayNo[0]);
salaries.sort();
for (var _i = 0, salaries_1 = salaries; _i < salaries_1.length; _i++) {
    var salary = salaries_1[_i];
    console.log(salary);
}
// arrayNo.pop();
// arrayNo.pop();
// arrayNo.pop();
// console.log(arrayNo);
