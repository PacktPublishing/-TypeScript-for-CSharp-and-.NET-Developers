
let arrayOne: string[];
let arrayTwo: string[] = [];
let arrayThree: string[] = new Array();
let arrayFour: string[] = Array();

let salaries = [2000, 3000, 9000, 1000];

console.log(salaries[3]);

let arrayNo = [];
console.log('Before Filling Array');
console.log(arrayNo);
arrayNo.push(1);
arrayNo.push(2);
arrayNo.push(3);
console.log(arrayNo);
console.log('After Filling Array');
console.log(arrayNo[0]);

salaries.sort();

for (let salary of salaries) {
  console.log(salary);
}



// arrayNo.pop();
// arrayNo.pop();
// arrayNo.pop();
// console.log(arrayNo);
