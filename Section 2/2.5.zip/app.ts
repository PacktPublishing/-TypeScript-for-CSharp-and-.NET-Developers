let isActive: boolean | number | string;
isActive = 'ahmad';
isActive = true;
isActive = 90;
console.log(isActive);

type Country = 'USA' | 'German' |
'Egypt' | 'South Africa' | 'India'
| 'Spain';

let countryName: Country;

countryName = 'China';

console.log(countryName);
