var isActive;
isActive = 'ahmad';
isActive = true;
isActive = 90;
console.log(isActive);
var countryName;
countryName = 'China';
console.log(countryName);
