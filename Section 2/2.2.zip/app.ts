
enum Sizes {
  Xsmall,
  Small = 100,
  Medium = 2,
  Large,
  Xlarge,
  XXlarge
}

console.log(Sizes.Large);

enum Colors {
  Red = 'Red',
  Blue = 'Blue',
  Green = 'Green'
}

console.log(Colors.Red);
