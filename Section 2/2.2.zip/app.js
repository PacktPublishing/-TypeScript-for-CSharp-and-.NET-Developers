var Sizes;
(function (Sizes) {
    Sizes[Sizes["Xsmall"] = 0] = "Xsmall";
    Sizes[Sizes["Small"] = 100] = "Small";
    Sizes[Sizes["Medium"] = 2] = "Medium";
    Sizes[Sizes["Large"] = 3] = "Large";
    Sizes[Sizes["Xlarge"] = 4] = "Xlarge";
    Sizes[Sizes["XXlarge"] = 5] = "XXlarge";
})(Sizes || (Sizes = {}));
console.log(Sizes.Large);
var Colors;
(function (Colors) {
    Colors["Red"] = "Red";
    Colors["Blue"] = "Blue";
    Colors["Green"] = "Green";
})(Colors || (Colors = {}));
console.log(Colors.Red);
